#include <iostream>
#include <string>
using namespace std;
class Passenger { public: string name; bool student=false, senior=false; };
class SmartCard {
    long long balance;
public:
    explicit SmartCard(long long b): balance(b) {}
    bool canTravel(long long fare) const { return balance-fare >= 5000; }
    bool deduct(long long fare) { if (!canTravel(fare)) return false; balance-=fare; return true; }
    long long getBalance() const { return balance; }
};
class FareTable { public: static long long fare(int zone) { return zone==1?1000:zone==2?2000:3000; } };
int main() {
    SmartCard card(10000);
    long long f=FareTable::fare(2);
    cout << "Middle zone fare: Rs " << f/100 << "." << (f%100<10?"0":"") << f%100 << '\\n';
    cout << "Journey allowed: " << boolalpha << card.deduct(f) << '\\n';
    cout << "Remaining balance (paise): " << card.getBalance() << '\\n';
}
