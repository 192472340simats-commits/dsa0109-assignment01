#include <iostream>
#include <string>
using namespace std;
long long baseFare(int zone) { return zone==1?1000:zone==2?2000:zone==3?3000:zone==4?6000:-1; }
bool peakHour(int h) { return (h>=8&&h<10)||(h>=17&&h<20); }
long long computeFare(int zone,int hour) {
    long long b=baseFare(zone);
    if(b<0||hour<0||hour>23) return -1;
    return peakHour(hour)?b*120/100:b;
}
int main() {
    struct Test { int zone,hour; long long expected; };
    Test tests[]={{1,7,1000},{2,8,2400},{3,10,3000},{3,17,3600},{4,20,6000},{9,12,-1}};
    for(auto t:tests) {
        long long actual=computeFare(t.zone,t.hour);
        cout<<"zone="<<t.zone<<" hour="<<t.hour<<" expected="<<t.expected
            <<" actual="<<actual<<" "<<(actual==t.expected?"PASS":"FAIL")<<'\\n';
    }
}
