#include <iostream>
#include <array>
using namespace std;
enum class Zone { Inner, Middle, Outer };
constexpr array<long long,3> FARES={1000,2000,3000};
long long fare(Zone z,bool peak) {
    long long b=FARES.at(static_cast<size_t>(z));
    return peak?b*120/100:b;
}
int main() {
    cout<<"Recommended: enum class, constexpr fare data, integer paise, long long balance\\n";
    cout<<"Middle peak fare: "<<fare(Zone::Middle,true)<<" paise\\n";
    cout<<"Per journey lookup: O(1); storage per card: O(1)\\n";
}
