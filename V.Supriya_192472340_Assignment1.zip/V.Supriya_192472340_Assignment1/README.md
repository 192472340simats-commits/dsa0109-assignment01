# ASSIGNMENT 1 – CO1
**Student Name:** V. Supriya  
**Register Number:** 192472340  
**Assignment:** Design, Implement and Validate the Fare Logic of a City Metro Smart-Card System

## Environment
Compiler: g++ (C++17)  
Compile command: `g++ -std=c++17 -Wall -Wextra source.cpp -o program`

## Folder contents
Each Task01–Task12 folder contains its C++ source file, compile log, executed output, terminal-style output screenshot, and a short README.

## Tasks
- Task01: Object-oriented analysis
- Task02: Tokens, keywords, identifiers and constants
- Task03: Data types and compatibility
- Task04: Implicit conversions
- Task05: Operators and precedence
- Task06: Control structures and completed code
- Task07: Procedural versus object-oriented
- Task08: Safe input and formatted output
- Task09: Implementation and testing
- Task10: Expectation versus execution and totals
- Task11: Final design recommendation
- Task12: Day-4 design challenge

## Notes
The programs are independently compilable demonstrations aligned to the task prompts. Replace or supplement the sample measurements and your own compiler/version details with the exact values from your computer before submission. Task 8 demonstrates safe string-to-number conversion and documents stream recovery; Task 1–12 written analysis, UML diagrams, pseudocode and measured complexity discussion should be added to the report as required by the PDF.
