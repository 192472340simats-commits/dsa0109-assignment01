Tokens, keywords, identifiers and constants
Source: task02.cpp
Compile: g++ -std=c++17 -Wall -Wextra task02.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
