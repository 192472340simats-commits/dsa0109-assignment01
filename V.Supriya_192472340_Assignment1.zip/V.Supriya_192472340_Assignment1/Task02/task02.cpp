#include <iostream>
using namespace std;
enum class Zone { Inner, Middle, Outer };
constexpr long long FARES[] = {1000,2000,3000};
constexpr int PEAK_PERCENT=20;
int main() {
    Zone z=Zone::Outer; // enum class identifier
    long long fare=FARES[static_cast<int>(z)];
    cout << "Outer base fare (paise): " << fare << '\\n';
    cout << "Peak surcharge (%): " << PEAK_PERCENT << '\\n';
}
