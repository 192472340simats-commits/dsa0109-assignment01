Control structures and completed code
Source: task06.cpp
Compile: g++ -std=c++17 -Wall -Wextra task06.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
