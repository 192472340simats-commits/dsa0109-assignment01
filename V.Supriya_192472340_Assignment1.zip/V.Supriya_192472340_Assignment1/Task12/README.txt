Day-4 design challenge
Source: task12.cpp
Compile: g++ -std=c++17 -Wall -Wextra task12.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
