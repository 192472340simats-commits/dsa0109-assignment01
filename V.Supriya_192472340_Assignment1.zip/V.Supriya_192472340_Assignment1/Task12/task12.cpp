#include <array>
#include <iostream>
using namespace std;
enum class Zone { Inner, Middle, Outer, Airport };
constexpr array<long long,4> FARES={1000,2000,3000,6000};
class MonthlyPass {
    bool active;
    bool covered[4];
public:
    MonthlyPass(bool a,bool z1,bool z2):active(a),covered{z1,z2,false,false}{}
    bool covers(Zone z) const { return active&&covered[static_cast<int>(z)]; }
};
long long revisedFare(Zone z,bool peak,bool weekend,const MonthlyPass& pass) {
    if(pass.covers(z)) return 0;
    long long f=FARES.at(static_cast<int>(z));
    if(weekend) return f*90/100; // weekend discount does not combine with peak
    return peak?f*120/100:f;
}
int main() {
    MonthlyPass pass(true,true,false);
    cout<<"Airport off-peak weekday: "<<revisedFare(Zone::Airport,false,false,pass)<<" paise\\n";
    cout<<"Outer weekend (no peak stacking): "<<revisedFare(Zone::Outer,true,true,pass)<<" paise\\n";
    cout<<"Inner covered by pass: "<<revisedFare(Zone::Inner,true,false,pass)<<" paise\\n";
}
