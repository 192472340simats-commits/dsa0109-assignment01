Data types and compatibility
Source: task03.cpp
Compile: g++ -std=c++17 -Wall -Wextra task03.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
