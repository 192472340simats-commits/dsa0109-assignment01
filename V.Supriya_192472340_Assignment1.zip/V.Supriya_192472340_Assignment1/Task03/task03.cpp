#include <climits>
#include <iostream>
using namespace std;
int main() {
    cout << "sizeof(bool): " << sizeof(bool) << '\\n';
    cout << "sizeof(int): " << sizeof(int) << '\\n';
    cout << "sizeof(long long): " << sizeof(long long) << '\\n';
    cout << "sizeof(double): " << sizeof(double) << '\\n';
    cout << "INT_MAX: " << INT_MAX << '\\n';
    long long journeys=3000000, farePaise=3600;
    cout << "Network total (paise): " << journeys*farePaise << '\\n';
    cout << "Network total (rupees): " << journeys*farePaise/100 << '\\n';
}
