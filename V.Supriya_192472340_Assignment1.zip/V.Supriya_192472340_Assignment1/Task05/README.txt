Operators and precedence
Source: task05.cpp
Compile: g++ -std=c++17 -Wall -Wextra task05.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
