#include <iostream>
using namespace std;
constexpr long long MIN_BALANCE=5000;
bool proceduralCanTravel(long long balance,long long fare) { return balance-fare>=MIN_BALANCE; }
class SmartCard {
    long long balance;
public:
    explicit SmartCard(long long b):balance(b){}
    bool canTravel(long long fare) const { return balance-fare>=MIN_BALANCE; }
    bool deduct(long long fare) { if(!canTravel(fare)) return false; balance-=fare; return true; }
    long long getBalance() const { return balance; }
};
int main() {
    long long balance=10000, fare=3000;
    cout<<"Procedural allowed: "<<boolalpha<<proceduralCanTravel(balance,fare)<<'\\n';
    SmartCard card(balance);
    cout<<"OOP deducted: "<<card.deduct(fare)<<'\\n';
    cout<<"OOP balance: "<<card.getBalance()<<" paise\\n";
}
