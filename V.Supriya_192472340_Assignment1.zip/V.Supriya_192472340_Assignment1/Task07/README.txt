Procedural versus object-oriented
Source: task07.cpp
Compile: g++ -std=c++17 -Wall -Wextra task07.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
