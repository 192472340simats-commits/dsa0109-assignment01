Safe input and formatted output
Source: task08.cpp
Compile: g++ -std=c++17 -Wall -Wextra task08.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
