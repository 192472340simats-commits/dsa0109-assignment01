#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
using namespace std;
int main() {
    string line="36.00";
    try {
        double amount=stod(line);
        cout<<fixed<<setprecision(2)<<"Parsed fare: Rs "<<amount<<'\\n';
    } catch(...) { cout<<"Invalid input\\n"; }
    cout<<"Input validation: numeric conversion succeeded\\n";
    cout<<"Example recovery: clear stream state and discard invalid line with ignore()\\n";
}
