#include <iostream>
#include <climits>
using namespace std;
int main() {
    const long long farePaise=3600;
    for(long long n:{20000LL,500000LL,3000000LL}) {
        long long total=n*farePaise;
        cout<<n<<" journeys: "<<total<<" paise = Rs "<<total/100<<'\\n';
    }
    cout<<"INT_MAX: "<<INT_MAX<<'\\n';
    cout<<"Use long long: 3,000,000 journeys exceed the safe int total range.\\n";
}
