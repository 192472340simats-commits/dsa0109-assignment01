Expectation versus execution and totals
Source: task10.cpp
Compile: g++ -std=c++17 -Wall -Wextra task10.cpp -o program
Run: ./program (Windows: program.exe)
See output.txt and output_screenshot.png for executed output.
